function TwoDimensionalAbsOU
% Absolute value of a 2D ornstein-uhlenbeck model of mood presented in
% "A comparison of mathematical models of mood in bipolar disorder"
% Amy Cochran, Andre Schultz, Melvin McInnis, Daniel Forger
% in "Computational Neurology and Psychiatry"

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------
rng(42) % random seed

% Parameters for manic variable
aM   = 0.15;            % Drift rate
sigM = 0.75;            % Stochasticity level 

% Parameters for depressive variable
aD   = 0.15;            % Drift rate
sigD = 0.5;             % Stochasticity level 

% Correlation between variables
rho  = -0.25;    

% Simulation parameters
Y  = 200;                     % Number of years of simulation
X0 = [0, 0];  % Start state

% Initialize sde model
mdl = sde(@(t,x) DriftTerm( x,t,aM, aD), ...
          @(t,x) [sigM, 0; 0, sigD],'StartState',X0',...
          'Correlation', [1, rho; rho, 1]);
    
% Simulate model for 2*Y years
X = simulate(mdl,2*Y*365,'DeltaTime',1,'NSTEPS',10,'Antithetic',false);

% Throw out first half of data and transform
X = abs( X(Y*365+2:2*Y*365+1,:) );      

PostAnalysis2D(X,[],'day','Absolute value of 2D OU');

function val = DriftTerm( x,t,aM,aD )
% Drift term for 2D double well model

% Variables
M  = x(1);   % Manic variable
D  = x(2);   % Depressive variable

% Differtial equations
val(1,1) = -aM*M;
val(2,1) = -aD*D;

