% Run Models
BehavioralActivation, pause(2)
BiologicalRhythmsBonsall, pause(2)
BiologicalRhythmsDaugherty, pause(2)
BiologicalRhythmsGoldbeter, pause(2)
DiscreteTimeBonsall, pause(2)
DiscreteTimeLopez, pause(2)
TwoDimensionalAbsOU, pause(2)
TwoDimensionalDoubleWell, pause(2)

% Gather Statistics
SimpleStats