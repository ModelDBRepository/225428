function BiologicalRhythmsDaugherty
% A biological rhythms model from
% Mathematical models of bipolar disorder
% Darryl Daugherty, Tairi Roque-Urrea, John Urrea-Roque, 
% Jessica Troyer, Stephen Wirkus, Mason A. Porter
% Commun Nonlinear Sci Numer Simulat 14 (2009) 2897�2908
%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------
rng(42) % random seed
% Parameters for van der Pol oscillator
alpha = 0.36/365;       % in day^{-1}  
beta  = -100/365;       % in day^{-1}   
omega = 5/365;          % in day^{-1/2}         
sig   = 0.02;           % Stochasticity level

% Simulation parameters
Y  = 200;               % Number of years of simulation
X0 = [0.1,0];           % Start state

% Initialize sde model
mdl = sde(@(t,x) DriftTerm(x,t,alpha,beta,omega), ...
          @(t,x) sig*[1; 0],'StartState',X0');
    
% Simulate model for 2*Y years
X = simulate(mdl,2*Y*365,'DeltaTime',1,'NSTEPS',10,'Antithetic',false);

% Throw out first half of data
X = X(Y*365+2:2*Y*365+1,:);      

PostAnalysis1D(X(:,1),[],'day','Daugherty''s Biological Rhythms');

function val = DriftTerm(x,t,alpha,beta,omega)
% Calculate drift term for biological rhythms model by Daugherty

% Variables
x1  = x(1);  % Mood 
y1  = x(2);  % Auxilliary variable

% Differtial equations
val(1,1) = y1 + (alpha*x1+beta*x1^3/3);
val(2,1) = -omega^2*x1;

