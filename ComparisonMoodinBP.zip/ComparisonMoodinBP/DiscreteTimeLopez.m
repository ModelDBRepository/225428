function DiscreteTimeLopez
% Four-state Discrete-Time Markov Chain based on ideas in
% Lopez, Adriana. 
% Markov models for longitudinal course of youth bipolar disorder. 
% ProQuest, 2008.

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------

rng(42) % random seed

% Probability Transition Matrix 
% State 1 - Euthymia
% State 2 - Depression
% State 3 - Mania
% State 4 - Mixed
P = [ 0.99 0.006 0.003 0.001; ...
      0.03 0.96 0.005 0.005; ...
      0.05 0.015 0.94 0.005; ...
      0.02 0.04 0.04  0.90 ];
  
% Simulation parameters
Y  = 200;              % Number of years of simulation
X0 = 1;               % Start state
X  = zeros(365*2*Y,1); % Initalize vector of moods

% Simulate model daily
for day = 1:365*2*Y
   X(day,1) = find( rand <= cumsum(P(X0,:)), 1, 'first' );
   X0        = X(day,1);
end

% Throw out first half of data
X = X(Y*365+1:2*Y*365,:);      

PostAnalysisDTMC(X(:,1),'day','Lopez''s DTMC');
