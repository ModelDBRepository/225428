This is companion Matlab code for the paper
"A comparison of mathematical models of mood in bipolar disorder"
Amy Cochran, Andre Schultz, Melvin McInnis, Daniel Forger
in the springerbook "Computational Neurology and Psychiatry"

Some comments:

1. If you are to use this code, please cite appropriately. 

2. Before you begin, you will need to download F. Mechler's 
Matlab package for Hardigan's dip test, which can be found at:
http://www.nicprice.net/diptest/

3. This package contains code to simulate eight different models 
of mood in bipolar disorder. To run them all and collect statistics, 
you type "RunModels" in the Matlab command window (without quotes). 

4. Model parameters are documented in the respective simulation file (see below)


Files contained in this package:

Main file
1. RunModels

Model simulation files:
1. BehavioralActivation.m
2. BiologicalRhythmsBonsall.m
3. BiologicalRhythmsDaugherty.m
4. BiologicalRhythmsGoldbeter.m
5. DiscreteTimeBonsall
6. DiscreteTimeLopez
7. TwoDimensionalAbsOU
8. TwoDimensionalDoubleWell


Analysis of simulation data
1. PostAnalysis1D
2. PostAnalysis2D
3. PostAnalysisDTMC
4. SimpleStats

Auxillary files needed to run SimpleStats.m from F.Mechler (see above)
1. HartigansDipSignifTest
2. HartigansDipTest
