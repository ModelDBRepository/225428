function Y = PostAnalysis2D(X,thresh,tUnits,ttl)
%--------------------------------------------------------------------------
% Generate figures from mood samples from a 2D model
% Inputs:
%   X       - n-by-2 of sampled mood states
%   thesh   - 1-by-2 vector for defining mood states (if relevant) 
%   tUnits  - string specifying whether samples were take daily or weekly
%   ttl     - string specifying title for figure
% Outputs:
%   Y       - structure containing data that is plotted in the figures
%--------------------------------------------------------------------------

% Set up figure
figure('name',ttl)
set(gcf,'Position',[10 50 1360 635])
set(gcf,'Color',[1 1 1])

%--------------------------------------------------------------------------
% Collect 
Y.X = X;                % Samples
Y.tUnits = tUnits;      % Sampling units
Y.thresh = thresh;      % Threshold for defining mood states
Y.Title  = ttl;         % Figure title
%--------------------------------------------------------------------------
% Plot the figures

% Figure 1 - Time course of mood over 2 years
subplot(2,3,1)
Y = Tracings(Y);

% Figure 2 - Histogram of mood values
subplot(2,3,2)
Y = Histogram(Y); 

% Figure 3 - Survival function for mood episodes
subplot(2,3,3)
Y = SurvivalFunction(Y);

% Figure 4 - Estimated spectral density using Thomson multitaper approach
subplot(2,3,4)
Y = ThomsonSpectrum(Y);

% Figure 5 - Scatter plot of concurrent manic and depressive scores
subplot(2,3,5)
Y = ScatterPlot(Y);

% Save data
save(ttl,'Y')


function Y = Tracings(Y)
%--------------------------------------------------------------------------
% Figure 1 - Weekly tracings
%--------------------------------------------------------------------------

% Normalize states
Y.NormalizedX = bsxfun(@times,bsxfun(@minus,Y.X,mean(Y.X)),1./std(Y.X) ); 

% Number of weeks and associated time vector
dur = 52*2;
T   = 1:dur;

% Gather last two years (52*2 weeks) of data (based on sampling units)
if strcmp(Y.tUnits,'day')                         
    % Sampled every day
    Y.Tracing = [T', Y.NormalizedX(end-dur*7+1:7:end,:)];
else
    % Sampled every week
    Y.Tracing = [T', Y.NormalizedX(end-dur:end,:)];
end

% Plot tracings
plot(Y.Tracing(:,1),Y.Tracing(:,[3,2]),'LineWidth',1.5)

% Plot Configurations
legend({'D','M'},'Box','off','Location','eastoutside')
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[0 dur])
xlabel('Week')
ylabel('Mood')

function Y = Histogram(Y)

%--------------------------------------------------------------------------
% Figure 2 - Histogram of normalized mood states
%--------------------------------------------------------------------------

% Create histogram
Y.HistXi(:,1) = linspace(-3,5,1000);
for i=1:size(Y.X,2)
    hold on
    Y.HistXi(:,i+1) = ksdensity(Y.NormalizedX(:,i),Y.HistXi(:,1));
end   
plot(Y.HistXi(:,1),Y.HistXi(:,[3 2]),'LineWidth',1.5)

% Plot Configurations
legend({'D','M'},'Box','off','Location','eastoutside')
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[min(Y.HistXi(:,1)), max(Y.HistXi(:,1))])
xlabel('Normalized mood')
ylabel('Probability density')


function Y = SurvivalFunction(Y)
%--------------------------------------------------------------------------
% Figure 3 - Survival curves
%--------------------------------------------------------------------------

% Define states based on whether mood is 0.5*std above mean
if isempty(Y.thresh)
    thresh(1,1) = quantile(Y.NormalizedX(:,1),0.8);
    thresh(1,2) = quantile(Y.NormalizedX(:,2),0.8);
    Y.state = sum( bsxfun(@times,Y.NormalizedX > ones(size(Y.X,1),1)*thresh,...
                                 1:size(Y.X,2)),  2 );
else
    Y.state = sum( bsxfun(@times,Y.X > ones(size(Y.X,1),1)*Y.thresh,...
                                 1:size(Y.X,2)),  2 );
end
% Generate samples of curves
ix    = find( Y.state(1:end-1) ~= Y.state(2:end) );
sc    = [ ix(2:end)-ix(1:end-1), Y.state(ix(2:end)) ];
Y.SurvivalCurve(:,1)    = linspace(0,28,1000)';
Y.CumHazard(:,1)        = linspace(0,28,1000)';
for i=[3,2,1,4]
   hold on
   tmp = sc(sc(:,2)==i-1 & sc(:,1) > 7,1)-7;
   if ~isempty(tmp)
       Y.SurvivalCurve(:,i+1) = ksdensity(tmp,Y.SurvivalCurve(:,1),...
                                     'support','positive','function','survivor');
       Y.CumHazard(:,i+1)     = ksdensity(tmp,Y.SurvivalCurve(:,1),...
                                     'support','positive','function','cumhazard');                          
       plot(Y.SurvivalCurve(:,1),Y.SurvivalCurve(:,i+1),'LineWidth',1.5)
   else
       Y.SurvivalCurve(:,i+1) = -1;
       Y.CumHazard(:,i+1)     = -1;
   end
end

% Plot Configurations
legend({'Depression','Mania','Euthymia','Mixed'},'Box','off','Location','eastoutside')
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[0, 28])
xlabel('Day')
ylabel('Survival probability')

function Y = ThomsonSpectrum(Y)
%--------------------------------------------------------------------------
% Figure 4 - Thomson Multitaper Estimate of Spectrum
%--------------------------------------------------------------------------


[Y.Spec(:,2),Y.Spec(:,1)] = pmtm(Y.NormalizedX(:,1),[],[],1);
[Y.Spec(:,3),~]           = pmtm(Y.NormalizedX(:,2),[],[],1);
plot(log10(Y.Spec(:,1)),10*log10(Y.Spec(:,[3,2])),'LineWidth',1.5)

% Plot Configurations
legend({'D','M'},'Box','off','Location','eastoutside')
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
xtick = log10( [1/365, 1/7] );
set(gca,'XTick',xtick)
set(gca,'XTickLabel',{'-log_{10}(365)','-log_{10}(7)'})
set(gca,'XLim',[log10(1/length(Y.X)),log10(max(Y.Spec(:,1)))])
xlabel('Log of Frequency in day^{-1}')
ylabel('Spectral density (dB/day^{-1})')

function Y = ScatterPlot(Y)
%--------------------------------------------------------------------------
% Figure 5 - Scatter plot of concurrent scores of mania and depression
%--------------------------------------------------------------------------

% Create histogram
plot(Y.NormalizedX(:,1),Y.NormalizedX(:,2),'.')

% Plot Configurations
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
%set(gca,'XLim',[min(Y.HistXi(:,1)), max(Y.HistXi(:,1))])
xlabel('Normalized manic variable')
ylabel('Normalized depression variable')
