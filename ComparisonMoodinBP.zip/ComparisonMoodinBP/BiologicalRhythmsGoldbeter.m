function BiologicalRhythmsGoldbeter
% A biological rhythms model from
% Goldbeter, A (2011) A model for the dynamics of bipolar disorders
% Progress in Biophysics and Molecular Biology 105 pp 119-127. 
% Random noise has been added to the model. 

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------
rng(42) % random seed
% Parameters for mania differential equation 
Vm  = 1;         % Maximum rate of cooperation from depression
Ki1 = 0.4;       % Half activation level for cooperation from depression
K1  = 0.5;       % Saturation level
km  = 0.5;       % Maximum rate of inhibition from mania
K2  = 0.5;       % Inhibition level

% Parameters for depression differential equation 
Vd  = 1;         % Maximum rate of cooperation from mania
Ki2 = 0.4;       % Half activation level for cooperation from mania
K3  = 0.5;       % Saturation level
kd  = 0.5;       % Maximum rate of inhibition from depression
K4  = 0.5;       % Inhibition level

% Parameters for mania saturation differential equation
kc1 = 0.02;      % Saturation rate of cooperation from mania
kc2 = 0.02;      % Saturation rate of inihibition from mania saturation

% Parameters for depression saturation differential equation
kc3 = 0.1;       % Saturation rate of cooperation from depression
kc4 = 0.1;       % Saturation rate of inihibition from depression saturation

% Other parameters
sig = 0.15;      % Stochasticity level

% Simulation parameters
Y  = 200;                         % Number of years of simulation
X0 = [0.026, 2.21, 0.16, 3.77];   % Start state

% Initialize sde model
mdl = sde(@(t,x) DriftTerm(x,t,Vm,Vd,K1,K2,K3,K4,Ki1,Ki2,km,kd,kc1,kc2,kc3,kc4), ...
          @(t,x) [sig,0;0,sig; 0,0; 0,0],'StartState',X0');
    
% Simulate model for 2*Y years
X = simulate(mdl,2*Y*365,'DeltaTime',1,'NSTEPS',10,'Antithetic',false);

% Throw out first half of data
X = X(Y*365+2:2*Y*365+1,:);      

PostAnalysis2D(X(:,1:2),[],'day','Goldbeter''s Biological Rhythms');

function val = DriftTerm(x,t,Vm,Vd,K1,K2,K3,K4,Ki1,Ki2,km,kd,kc1,kc2,kc3,kc4)
% Calculate drift term for biological rhythms model by Goldbeter

% Variables
M  = x(1);  % Mania 
D  = x(2);  % Depression
Fm = x(3);  % Mania Saturation
Fd = x(4);  % Depression Saturation

% Differtial equations
val(1,1) = Vm*Ki1^2 / ( Ki1^2+D^2 ) * Fd / ( K1+Fd ) - km*M / ( K2+M );
val(2,1) = Vd*Ki2^2 / ( Ki2^2+M^2 ) * Fm / ( K3+Fm ) - kd*D / ( K4+D );
val(3,1) = kc1*M - kc2*Fm;
val(4,1) = kc3*D - kc4*Fd;

