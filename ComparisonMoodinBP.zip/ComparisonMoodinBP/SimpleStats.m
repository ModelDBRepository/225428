function SimpleStats
% Collect Results 

% List of models
ModelList = { 'Behavioral Activation', ...
              'Bonsall''s Autoregressive', ...
              'Bonsall''s Biological Rhythms', ...
              'Daugherty''s Biological Rhythms', ...
              'Goldbeter''s Biological Rhythms', ...
              'Lopez''s DTMC',...
              '2D Double Well',...
              'Absolute value of 2D OU'};

% Initialize
stats = NaN*ones(length(ModelList),11);
          
% Loop through models and store results
for i= 1:length(ModelList)

    % Load data
    load(ModelList{i})
   
    % Two-dimensional model
    if size(Y.X,2)==2
        
        % Correlation
        cc0 = corr(Y.X(:,1),Y.X(:,2),'type','Pearson');
        cc1 = corr(Y.X(:,1),Y.X(:,2),'type','Kendall');
        cc2 = corr(Y.X(:,1),Y.X(:,2),'type','Spearman');
        
        % Unimodality
        tmp1 = HartigansDipTest(Y.X(:,1));                  
        tmp2 = HartigansDipTest(Y.X(:,2));
        
        % Collect stats
        stats(i,:) = [skewness(Y.X),kurtosis(Y.X),tmp1,tmp2,NaN,NaN,cc0,cc1,cc2];
    
    % One-dimensional models
    else
        % Unimodality (with P-Value)
        tmp1     = HartigansDipTest(Y.X);                      
        [~,tmp3] = HartigansDipSignifTest(Y.X(1:7:52*7),500); % One year of weekly data
        
        % Test of normality
        tmp4 = TestStatDist(Y.X(1:7:52*7));
        
        % Collect States
        stats(i,:) = [skewness(Y.X),NaN,kurtosis(Y.X),NaN,tmp1,NaN,tmp3,tmp4,NaN,NaN,NaN];            
    end
    
end

% Write to excel file
header = {'Model','Skewness','','Kurtosis','','Dip','','Dip P-value',...
          'Normality P-value','Pearson','Kendall','Spearman'};
xlswrite('Stats',stats,'Stats','B2')
xlswrite('Stats',ModelList(:),'Stats','A2')
xlswrite('Stats',header,'Stats','A1')

function p = TestStatDist(r)
% Test the null hypothesis that r comes from a Gamma distribution

% Step 1 - Get Maximum likelihood estimate
th = mle(r,'distribution','normal');

% Step 2 - Compute Test Statistic
tst = getTestStatistic(th,r(:));

% Step 3 - Bootstrap  Test Statistic
M   = 10^3;
n   = length(r);
Y   = normrnd(th(1),th(2),M,n); 
TST = NaN*ones(M,1);

% Computate test statistic for each random variable
for j=1:M
    th0      = mle(Y(j,:)','distribution','normal'); 
    TST(j,1) = getTestStatistic(th0,Y(j,:)');
end

% Estimate p-value using MC samples and kernel
p = 1 - ksdensity(TST,tst,'support','positive','function','cdf');


function tst = getTestStatistic(th,r)
% Get test statistic using weighted sum of square error

w    = abs( r - mean(r) ) < 2*std(r);       % Weight (to exclude outliers)
tmp  = ksdensity(r,r);                      % Non-parametric approx.
tmp0 = normpdf(r,th(1),th(2));                % Parametric approx.
tst = sum( w.*( tmp0 - tmp ).^2 ) ;          % Test statistic

