function DiscreteTimeBonsall
% Autoregressive model of mood from
% Nonlinear time-series approaches in characterizing mood stability and 
% mood instability in bipolar disorder
% M. B. Bonsall, S. M. A. Wallace-Hadrill, J. R. Geddes, 
% G. M. Goodwin, E. A. Holmes
% Proc. R. Soc. B 2012 279 916-924; DOI: 10.1098/rspb.2011.1246. 

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------

rng(42) % random seed

% Parameters
a     = 1/10;         % Intercept
b     = 1-1/10;       % Slope    
alpha = 10;           % Shape parameter

% Simulation parameters
Y  = 200;              % Number of years of simulation
X0 = 1;               % Start state
X  = zeros(365*2*Y,1); % Initalize vector of moods

% Simulate model for every week
for day = 1:365*2*Y
   X(day,1) = gamrnd(alpha,(a+b*X0)/alpha);
   X0       = X(day,1);
end

% Throw out first half of data
X = X(Y*365+1:2*Y*365,:);      

PostAnalysis1D(X,[],'day','Bonsall''s Autoregressive');