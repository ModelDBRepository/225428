function BiologicalRhythmsBonsall
% Biological rhythms model presented in
% Bipolar disorder dynamics: affective instabilities, 
% relaxation oscillations and noise
% Michael B. Bonsall, John R. Geddes, Guy M. Goodwin, Emily A. Holmes
% J. R. Soc. Interface 2015 12 20150670; DOI: 10.1098/rsif.2015.0670. 

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------
rng(42) % random seed
% Parameters for relaxation oscillator 1
zeta1  = 0.5;            % Stable point
omega1 = 1/sqrt(20);     % Relaxation slope
th1    = 1;              % Coupling exponent
eta1   = 0.05;           % Coupling strength

% Parameters for relaxation oscillator 2
zeta2  = 0.5;            % Stable point
omega2 = 1.5/sqrt(20);   % Relaxation slope
th2    = 1;              % Coupling exponent
eta2   = 0.05;           % Coupling strength

% Strength of contributions to mood
c0  = 0;      % Constant term
c1  = 1;      % Relaxation Oscillator 1 strength
c2  = 1;      % Relaxation Oscillator 2 strength
sig = 0.1;    % Stochasticity level

% Simulation parameters
Y  = 200;                    % Number of years of simulation
X0 = [0, -0.6, 0, -0.6, 0];  % Start state

% Initialize sde model
mdl = sde(@(t,x) DriftTerm( x,t,zeta1,zeta2,omega1,omega2,...
                            eta1,eta2,th1,th2,c0,c1,c2), ...
          @(t,x) [zeros(1,4); sig*eye(4)],'StartState',X0');
    
% Simulate model for 2*Y years
X = simulate(mdl,2*Y*365,'DeltaTime',1,'NSTEPS',10,'Antithetic',false);

% Throw out first half of data
X = X(Y*365+2:2*Y*365+1,:);      

% Analyze data
PostAnalysis1D(X(:,1),[],'day','Bonsall''s Biological Rhythms');

function val = DriftTerm(x,t,zeta1,zeta2,omega1,omega2,eta1,eta2,...
                         th1,th2,c0,c1,c2)
% Calculate drift term for biological rhythms model by Goldbeter

% Variables
M   = x(1);  % Mood
x1  = x(2);  % Relaxation  Ocillator 1 
y1  = x(3);  % Relaxation Oscillator 1 (auxilliary parameter)
x2  = x(4);  % Relaxation  Ocillator 2 
y2  = x(5);  % Relaxation Oscillator 2 (auxilliary parameter)

% Differtial equations
dXdt     = y1 + (x1-x1^3/3) + eta1./(1+exp(th1*x2));
dZdt     = y2 + (x2-x2^3/3) + eta2./(1+exp(th2*x1));
val(1,1) = c0 + c1*dXdt + c2*dZdt;
val(2,1) = dXdt;
val(3,1) = -omega1^2*(x1+zeta1);
val(4,1) = dZdt;
val(5,1) = -omega2^2*(x2+zeta2);

