function Y = PostAnalysisDTMC(X,tUnits,ttl)
%--------------------------------------------------------------------------
% Generate figures from mood samples from discete-time Markov chain model
% Inputs:
%   X       - n-by-1 of sampled mood states
%   tUnits  - string specifying whether samples were take daily or weekly
%   ttl     - string specifying title for figure
% Outputs:
%   Y       - structure containing data that is plotted in the figures
%--------------------------------------------------------------------------

% Set up figure
close all
figure('name',ttl)
set(gcf,'Position',[10 50 1360 635])
set(gcf,'Color',[1 1 1])

%--------------------------------------------------------------------------
% Collect 
Y.X = X;                % Samples
Y.tUnits = tUnits;      % Sampling units
Y.Title  = ttl;         % Figure title
%--------------------------------------------------------------------------
% Plot the figures

% Figure 1 - Time course of mood over 2 years
subplot(2,2,1)
Y = Tracings(Y);

% Figure 2 - Histogram of mood values
subplot(2,2,2)
Y = Histogram(Y); 

% Figure 3 - Survival function for mood episodes
subplot(2,2,3)
Y = SurvivalFunction(Y);

% Figure 4 - Estimated spectral density using Thomson multitaper approach
subplot(2,2,4)
Y = ThomsonSpectrum(Y);

% Save data
save(ttl,'Y')


function Y = Tracings(Y)
%--------------------------------------------------------------------------
% Figure 1 - Weekly tracings
%--------------------------------------------------------------------------

% Do not normalize states
Y.NormalizedX = Y.X; 

% Number of weeks and associated time vector
dur = 52*2;
T   = 1:dur;

% Gather last two years (52*2 weeks) of data (based on sampling units)
if strcmp(Y.tUnits,'day')                         
    % Sampled every day
    Y.Tracing = [T', Y.NormalizedX(end-dur*7+1:7:end,:)];
else
    % Sampled every week
    Y.Tracing = [T', Y.NormalizedX(end-dur:end,:)];
end

% Plot tracings
plot(Y.Tracing(:,1),Y.Tracing(:,2),'LineWidth',1.5,'Color','m')

% Plot Configurations
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[0 dur])
set(gca,'YTick',[1,2,3,4])
set(gca,'YLim',[1,4])
set(gca,'YTickLabel',{'Euthymia','Depression','Mania','Mixed'})
xlabel('Week')
ylabel('Mood state')

function Y = Histogram(Y)

%--------------------------------------------------------------------------
% Figure 2 - Histogram of normalized mood states
%--------------------------------------------------------------------------

% Create histogram
Y.HistXi(:,1) = ( 1:4 )';
Y.HistXi(:,2) = accumarray(Y.X,1)/length(Y.X);
bar(Y.HistXi(:,1),Y.HistXi(:,2),'FaceColor','m')

% Plot Configurations
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[0.5, 4.5])
set(gca,'XTick',1:4)
set(gca,'XtickLabel',{'Euthymia','Depression','Mania','Mixed'})
ylabel('Probability')


function Y = SurvivalFunction(Y)
%--------------------------------------------------------------------------
% Figure 3 - Survival curves
%--------------------------------------------------------------------------

% Mood states
Y.state = Y.X-1;

% Generate samples of curves
ix    = find( Y.state(1:end-1) ~= Y.state(2:end) );
sc    = [ ix(2:end)-ix(1:end-1), Y.state(ix(2:end)) ];
Y.SurvivalCurve(:,1)    = linspace(0,28,1000)';
Y.CumHazard(:,1)        = linspace(0,28,1000)';
for i=[3,2,1,4]
   hold on
   tmp = sc(sc(:,2)==i-1 & sc(:,1) > 7,1)-7;
   if ~isempty(tmp)
       Y.SurvivalCurve(:,i+1) = ksdensity(tmp,Y.SurvivalCurve(:,1),...
                                     'support','positive','function','survivor');   
       Y.CumHazard(:,i+1)     = ksdensity(tmp,Y.SurvivalCurve(:,1),...
                                     'support','positive','function','cumhazard');                             
       plot(Y.SurvivalCurve(:,1),Y.SurvivalCurve(:,i+1),'LineWidth',1.5)
       
   else
       Y.SurvivalCurve(:,i+1) = NaN;
       Y.CumHazard(:,i+1)     = NaN;
   end
end

% Plot Configurations
legend({'Depression','Mania','Euthymia','Mixed'},'Box','off','Location','northeast')
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])
set(gca,'XLim',[0, 28])
xlabel('Day')
ylabel('Survival probability')

function Y = ThomsonSpectrum(Y)
%--------------------------------------------------------------------------
% Figure 4 - Thomson Multitaper Estimate of Spectrum
%--------------------------------------------------------------------------


[Y.Spec(:,2),Y.Spec(:,1)] = pmtm(Y.X(:,1),[],[],1);
plot(log10(Y.Spec(:,1)),10*log10(Y.Spec(:,2)),'LineWidth',1.5,'Color','m')

% Plot Configurations
set(gca,'FontSize',16,'FontName','Times','Box','off','LineWidth',1.5,...
        'XColor',[0.1 0.1 0.1],'YColor',[0.1 0.1 0.1])

xtick = log10( [1/365, 1/7] );
set(gca,'XTick',xtick)
set(gca,'XTickLabel',{'-log_{10}(365)','-log_{10}(7)'})
set(gca,'XLim',[log10(1/length(Y.X)),log10(max(Y.Spec(:,1)))])
xlabel('Log of Frequency in day^{-1}')
ylabel('Spectral density (dB/day^{-1})')