function BehavioralActivation
% Behavioral activation model from
% Steinacher A, Wright KA (2013) Relating the Bipolar Spectrum to 
% Dysregulation of Behavioural Activation: A Perspective from Dynamical 
% Modelling. PLoS ONE 8(5): e63345. doi: 10.1371/journal.pone.0063345

%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------
rng(42) % random seed

% Positive feedback parameters
k1 = 1.5;    % Maximum rate for positive feedback in hr^(-1) 
K  = 100;    % Half-activation level for positive feedback
n  = 8;      % Nonlinear constant

% Negative feedback parameters
mh = 0.26;   % Twice max-activation rate for negative feedback
s  = 5;      % Nonlinearity parameter for negative feedback
xh = 100;    % Half-activation level for negative feedback

% Reward processing parameters
k3    = 5;      % Activation rate from reward processing in hr^(-1)
probR = 0.015;  % Probability of activation in a day
ampR  = 20;     % Maximum activation (assuming beta dist)


% Other parameters
k2  = 0.0125; % Decay rate in hr^(-1)
b   = 0.5;    % Influx of activation
sig = 0.1;    % Stochasticity level

% Simulation parameters
Y  = 200;           % Number of years of simulation
X0 = [100,0];       % Start state
dt = 24/(48*2);     % Time increment in hours

% Initialize state vector
X  = zeros(2*Y*365,2); 

% Simulate for Y years (Euler approximation)
for day = 1:2*Y*365
    
    for t = 1:24/dt
        % Continuous part
        X(day,:) = X0 + DriftTerm(X0,[],k1,k2,k3,b,K,mh,s,xh,n)'*dt + ...
                        randn(1,2)*(sig*sqrt(dt)) ;
 
        % Jump part
        if rand < probR
            X(day,2) = 2*ampR*(betarnd(4,4)-1/2);
        end

        % Update state
        X0 = X(day,:);
    end
    
end

PostAnalysis1D(X(:,1),[],'day','Behavioral Activation');

function val = DriftTerm(x,t,k1,k2,k3,b,K,mh,s,xh,n)
% Calculate drift term for behavioral activation model

% Activation
E = x(1); 

% Reward processing
R = x(2);

% Positive feedback term
PF = k1*E^n / (K^n + E^n );

% Negative feedback term
NF = mh*( 1/2 - 1/(1+exp(s*(xh-E))) );

% Activation drift
val(1,1) = PF + NF + b - k2*E + k3*R;

% Reward drift
val(2,1) = -k3*R;



