function TwoDimensionalDoubleWell
% A 2D "Double Well" model of mood presented in
% "A comparison of mathematical models of mood in bipolar disorder"
% Amy Cochran, Andre Schultz, Melvin McInnis, Daniel Forger
% in "Computational Neurology and Psychiatry"


%--------------------------------------------------------------------------
% Initialize parameters
%--------------------------------------------------------------------------

rng(42) % random seed

% Parameters for manic variable
aM   = 0.15;            % Drift rate
lM   = -2.25;           % Low stable state
hM   = 1;               % High stable state
sigM = 0.75;            % Stochasticity level 

% Parameters for depressive variable
aD   = 0.15;             % Drift rate
lD   = -2;              % Low stable state
hD   = 1;               % High stable state
sigD = 0.5;             % Stochasticity level 

% Correlation between variables
rho  = -0.25;    

% Simulation parameters
Y  = 200;                     % Number of years of simulation
X0 = [0, 0];  % Start state

% Initialize sde model
mdl = sde(@(t,x) DriftTerm( x,t,aM,lM,hM,aD,lD,hD), ...
          @(t,x) [sigM, 0; 0, sigD],'StartState',X0',...
          'Correlation', [1, rho; rho, 1]);
    
% Simulate model for 2*Y years
X = simulate(mdl,2*Y*365,'DeltaTime',1,'NSTEPS',10,'Antithetic',false);

% Throw out first half of data
X = X(Y*365+2:2*Y*365+1,:);      

PostAnalysis2D(X,[],'day','2D Double Well');

function val = DriftTerm( x,t,aM,lM,hM,aD,lD,hD )
% Drift term for 2D double well model

% Variables
M  = x(1);   % Manic variable
D  = x(2);   % Depressive variable

% Differtial equations
val(1,1) = -aM*M*(M-lM)*(M-hM);
val(2,1) = -aD*D*(D-lD)*(D-hD);

